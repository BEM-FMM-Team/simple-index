"""""" # start delvewheel patch
def _delvewheel_patch_1_13_2():
    import os
    if os.path.isdir(libs_dir := os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'fmm3dpyfast.libs'))):
        os.add_dll_directory(libs_dir)


_delvewheel_patch_1_13_2()
del _delvewheel_patch_1_13_2
# end delvewheel patch

from .fmm3d import hfmm3d,lfmm3d,emfmm3d,stfmm3d,h3ddir,l3ddir,em3ddir,st3ddir,comperr,Output
__version__ = '2.1.0'
